from django.apps import AppConfig


class AladinappConfig(AppConfig):
    name = 'aladinapp'
