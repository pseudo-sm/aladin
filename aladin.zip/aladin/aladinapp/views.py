import difflib
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse,HttpResponseRedirect
from django.shortcuts import render,HttpResponse
import pyrebase
from django.contrib import messages
from django.contrib import auth as authe
from requests.exceptions import HTTPError
import datetime
import json
from django.contrib import messages


# Create your views here.
config = {
   "apiKey": "AIzaSyAJwqZ7wMQBtz8W4wXpUhExmaj8LnLu70Q",
    "authDomain": "aladin-38310.firebaseapp.com",
    "databaseURL": "https://aladin-38310.firebaseio.com",
    "projectId": "aladin-38310",
    'storageBucket': "aladin-38310.appspot.com",
    "messagingSenderId": "169120108675"


  };

firebase = pyrebase.initialize_app(config)
db = firebase.database()
auth = firebase.auth()
storage = firebase.storage()

def fetch(request):
    uids = []
    oids = []
    name = []
    amount = []
    upids = []
    data = dict(db.child("users").child('patients').get().val())
    data_doc = db.child("users").child("doctors").get().val()
    orders = db.child("orders").get().val()
    for oid in orders:
        uid = orders[oid]
        orders_particular = data_doc["gNoXlkVcTMQvbXdDu6djL5oq6Py2"]["orders"]

    for oid in orders_particular:
        uid = db.child("orders").child(oid).get().val()

        if (int(db.child("users").child("patients").child(uid).child("orders").child(oid).child("status").get().val()) <= 1):
            uids.append(uid)
            oids.append(oid)
            name.append(data[uid]["name"])
            upids.append(data[uid]["orders"][oid]["upi id"])
            amount.append(data[uid]["orders"][oid]["amount"])
            db.child("users").child("doctors").child("gNoXlkVcTMQvbXdDu6djL5oq6Py2").child("orders").update({oid:1})

    det = zip(uids,oids,name,upids,amount)

    return render(request,"home.html",{"det":det})

def update(request):

    data_doc = dict(db.child("users").child('doctors').child("gNoXlkVcTMQvbXdDu6djL5oq6Py2").child("orders").get().val())
    data_pat = dict(db.child("users").child('patients').get().val())
    orders = dict(db.child("orders").get().val())
    name = []
    oids = []
    upid = []
    amount = []
    content = {"sound":False}
    for oid in data_doc:

        if data_doc[oid] == 0:
            uid = orders[oid]

            name.append(data_pat[uid]["name"])
            upid.append(data_pat[uid]["orders"][oid]["upi id"])
            amount.append(data_pat[uid]["orders"][oid]["amount"])
            oids.append(oid)
            all = zip(name,upid,amount,oids)
            db.child("users").child('doctors').child("gNoXlkVcTMQvbXdDu6djL5oq6Py2").child("orders").update({oid:1})
            content = {"uid":uid,"name":name,"upid":upid,"amount":amount,"oids":oids,"count":len(oids)}
            content.update({"sound":True})
            print(content)

    return HttpResponse(json.dumps(content), content_type='application/json')

def doctor_update(request):

    orders = dict(db.child("orders").get().val())
    for oid in orders:
        uid = orders[oid]
        user = auth.current_user
        patient = dict(db.child("users").child("patients").child(uid).get().val())
        all = {"sound":False}
        try:
            if (patient["orders"][oid]["seen"] == "0"):
                name = patient["name"]
                ps = storage.child("users").child("patients").child(uid).child("orders").child(oid).child("prescription").get_url(user['idToken'])
                rp = storage.child("users").child("patients").child(uid).child("orders").child(oid).child("reports").get_url(user['idToken'])

                all = {"oid":oid,"uid":uid,"name":name,"prescription":ps,"report":rp}
                db.child("users").child("patients").child(uid).child("orders").child(oid).update({"seen":"1"})
                all.update({"sound":True})
        except KeyError:
            pass
        return HttpResponse(json.dumps(all), content_type='application/json')

def doctor(request):

    oids = []
    uids = []
    names =  []
    prescriptions = []
    reports = []

    auth.sign_in_with_email_and_password("doctor@gmail.com","password")
    user = auth.current_user
    data = dict(db.child("orders").get().val())
    for i in data:
        order = dict(db.child("users").child("patients").child(data[i]).child("orders").child(i).get().val())
        if(order["status"] == "2" ):
            if(order["doctor"] == "0"):

                oids.append(i)
                uid = data[i]
                uids.append(uid)
                names.append(db.child("users").child("patients").child(uid).child("name").get().val())
                ps = storage.child("users").child("patients").child(uid).child("orders").child(i).child("prescription").get_url(user['idToken'])
                rp = storage.child("users").child("patients").child(uid).child("orders").child(i).child("reports").get_url(user['idToken'])
                prescriptions.append(ps)
                reports.append(rp)
                db.child("users").child("patients").child(data[i]).child("orders").child(i).update({"seen":"1"})

    data = zip(oids,uids,names,prescriptions,reports)
    return render(request,"doctors.html",{"data":data})
def verify(request):

    oid = request.GET.get("oid")
    action = request.GET.get("action")
    uid = db.child("orders").child(oid).get().val()
    if action == "accept":
        #2 verified successfully
        messages.success(request, 'Verified !')
        db.child("users").child("patients").child(uid).child("orders").child(oid).update({"status":"2","seen":"0","doctor":"0"})
    else:
        #3 cancelled by backend team
        db.child("users").child("patients").child(uid).child("orders").child(oid).update({"status":"3"})
        messages.warning(request, 'Request Declined !')
    content = {"status":True}

    return HttpResponse(json.dumps(content), content_type='application/json')

def upload(request):
    db.child("asas").update({"sas":"wat"})

    return HttpResponse("sas")
